from django.db import models
from datetime import date, datetime
import random
from django.utils import timezone
import uuid
from django.core.validators import RegexValidator


# Customize user form starts here

from django.db import models
from django.contrib.auth.models import (
    BaseUserManager, AbstractBaseUser
)

class UserManager(BaseUserManager):
    def create_user(self, phone_number, name, designation, posted_at, password=None):
        """
        Creates and saves a User with the given email and password.
        """
        if not phone_number:
            raise ValueError('Users must have a email')

        user = self.model(
            phone_number =phone_number,
            name = name,
            designation = designation,
            posted_at = posted_at
        )

        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, phone_number, password):
        """
        Creates and saves a superuser with the given email and password.
        """
        user = self.create_user(
            phone_number,
            password=password,
        )
        user.is_staff = True
        user.is_admin = True
        user.save(using=self._db)
        return user
   

class User(AbstractBaseUser):
    id = models.UUIDField(default=uuid.uuid4, unique=True, primary_key=True, editable=False)
    phone_regex = RegexValidator(regex=r'^\+?1?\d{9,15}$', message="Enter valid phone number.")
    phone_number = models.CharField(validators=[phone_regex], max_length=17, unique=True) # validators should be a list
    designation_choice = (
        ('TCM-1', 'TCM-1'),
        ('TCM-2', 'TCM-2'),
        ('TCM-3', 'TCM-3'),
        ('MCM','MCM'),
        ('JE', 'JE'),
        ('SSE', 'SSE')
    )

    designation = models.CharField(max_length=10, choices=designation_choice)

    name = models.CharField(max_length=100)

    posted_at = models.CharField(max_length=100)
    
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False) # a is_admin user; non super-user
    is_admin = models.BooleanField(default=False) # a superuser

    # notice the absence of a "Password field", that is built in.

    USERNAME_FIELD = 'phone_number'
    REQUIRED_FIELDS = ['name', 'designation', 'posted_at'] # Email & Password are required by default.

    objects = UserManager()

    def has_perm(self, perm, obj=None):
        return True

    def has_module_perms(self, app_label):
        return True




# Create your models here.

class CreatePoleModel(models.Model):
    id = models.UUIDField(default=uuid.uuid4, unique=True, primary_key=True, editable=False)
    depo_choice = (        
        ('NGP-AMLA', 'NGP-AMLA'),
        ('NGP-WR', 'NGP-WR'),  
        ('WR-BD', 'WR-BD'),
        ('WR-WRR', 'WR-WRR'),
        ('WRR-BPQ', 'WRR-BPQ'),      
    )
    select_depo = models.CharField(max_length=20, choices=depo_choice)  
    km_no = models.CharField(max_length=100)
    section = models.CharField(max_length=100)
    up_down = models.CharField(max_length=100)
    pole_remark = models.CharField(max_length=500, blank=True)
    qrlink =models.CharField(max_length=70, default='http://localhost:8000/qr/'+ str(random.randint(10000, 9999999)))
    svg = models.CharField(max_length=1000)
    
class TestRoomInterface(models.Model):
    id = models.UUIDField(default=uuid.uuid4, unique=True, primary_key=True, editable=False)
    pole_id = models.ForeignKey(CreatePoleModel, on_delete = models.CASCADE)
    depo_choice = (        
        ('NGP-AMLA', 'NGP-AMLA'),
        ('NGP-WR', 'NGP-WR'),  
        ('WR-BD', 'WR-BD'),
        ('WR-WRR', 'WR-WRR'),
        ('WRR-BPQ', 'WRR-BPQ'),      
    )
    pole_depo = models.CharField(max_length=20, choices=depo_choice, blank=True)  
    km_no = models.CharField(max_length=100)
    section = models.CharField(max_length=100)
    up_down = models.CharField(max_length=100)
    pole_remark = models.CharField(max_length=500, blank=True)

    scanner_id = models.ForeignKey(User, on_delete = models.CASCADE, related_name = "user_scanner_id")
    scanner_name = models.CharField(max_length = 100)
    scanner_designation = models.CharField(max_length = 100)
    time_stamp  = models.DateTimeField(default = timezone.now())
    latitude = models.CharField(max_length = 100)
    longitude = models.CharField(max_length = 100)
    onduty_staff = models.ForeignKey(User, on_delete = models.CASCADE, related_name = "onduty_staff_id")
    onduty_staff_name = models.CharField(max_length=100)
    testroom_remark =  models.CharField(max_length = 500, blank=True)
    Profile_status= (
        ('Pending', 'Pending'),
        ('Faulty', 'Faulty'),
        ('Working', 'Working'),
    )
    
    update_profile = models.CharField(max_length=20, choices=Profile_status , default="Pending")

