from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from QRDataBase.models import CreatePoleModel, TestRoomInterface, User
from django import forms

class UserSignupForm(UserCreationForm):
    class Meta:
        model = User
        fields = '__all__'


class UserLoginForm(AuthenticationForm):
    class Meta:
        model = User
        fields = ['phone_number']

class CreatePoleModelForm(forms.ModelForm):
    
    class Meta:
        model = CreatePoleModel
        fields = ['select_depo','km_no','section','up_down', 'pole_remark']        
       
    


class TestRoomInterfaceForm(ModelForm):
    class Meta:
        model = TestRoomInterface
        fields = '__all__'

class DateInput(forms.DateInput):
    input_type = 'date'

class AdminFilter(ModelForm):
    class Meta:
        model = TestRoomInterface
        fields = ['pole_depo', 'update_profile', 'time_stamp']
        widgets = {
            'time_stamp' : DateInput(),
        }