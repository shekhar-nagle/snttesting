from django.shortcuts import render ,redirect                                   # 

from django.contrib.auth.forms import UserCreationForm, AuthenticationForm       #  deafult user form and auth forms from django
from django.contrib.auth.models import auth                            # importing user object and user auth object
from django.db import IntegrityError                                            # 
from django.contrib.auth import login, logout, authenticate                     # other user operations 
from .forms import CreatePoleModelForm, TestRoomInterfaceForm, AdminFilter, UserSignupForm, UserLoginForm
from .models import CreatePoleModel, TestRoomInterface, User
import json
from django.contrib.auth.decorators import login_required



def test(request):    
        return render(request,'test.html')

def adminn(request):    
    return render(request,'index.html')

def signup(request):
    if (request.method == 'GET'):
        return render(request, 'signup.html', {'form' : UserSignupForm()})  
    else:
        #check if the passwords match
        
       
        user = User.objects.create_user(request.POST['phone_number'],request.POST['name'],request.POST['designation'],request.POST['posted_at'], password = request.POST['password1'])
        user.save()
        login(request, user)
        return redirect('home')

        # except Exception:
        #     print(Exception)
        #     return render(request, 'signup.html', {'form' : UserSignupForm(), 'error' : 'User is Not Available'})
    

def logoutuser(request):
    auth.logout(request)
    return redirect('home')

def loginuser(request):
    if (request.method == 'GET'):
        return render(request, 'login.html', {'form' : UserLoginForm()})  
    else:
        #check if the passwords match
        user = authenticate(request, phone_number=request.POST['username'] , password=request.POST['password'])
        if user is None:
            return render(request, 'login.html', {'form' : UserLoginForm(), 'error':'login username and password does not matched'})
        else:
            login(request, user)
            if(request.GET.get('next')):
                return redirect(request.GET.get('next'))
            else:
                return redirect('home')

@login_required(login_url = 'loginuser')
def QRInfoByQRLink(request, search_by_qrlink):
    if request.method == 'GET':
        if request.user.is_authenticated :
        # search_by_qrlink = request.GET['search_by_qrlink']
        
            poledata = CreatePoleModel.objects.get(qrlink = 'http://localhost:8000/qr/'+ str(search_by_qrlink))
            user = request.user
            form = TestRoomInterfaceForm()
            
            newobj =form.save(commit=False)
            newobj.scanner_id = user
            newobj.pole_id = poledata
            newobj.pole_depo = poledata.select_depo
            newobj.section = poledata.section
            newobj.up_down = poledata.up_down
            newobj.km_no = poledata.km_no
            newobj.pole_remark = poledata.pole_remark
            newobj.scanner_name =user.name
            newobj.scanner_designation = user.designation
    
            newobj.save() 
            return render(request, 'location.html')               
    elif request.method == 'POST':        
        latitude = request.POST.get("latitude")
        longitude = request.POST.get("longitude")
        poledata = CreatePoleModel.objects.get(qrlink = 'http://localhost:8000/qr/'+ str(search_by_qrlink))
        testRoomObj = TestRoomInterface.objects.filter(pole_id = poledata).latest('time_stamp')
        print("Inside POST")
        print(testRoomObj.time_stamp)
        testRoomObj.latitude = latitude
        testRoomObj.longitude = longitude
        testRoomObj.save()
        return redirect('qrinfodata')

@login_required(login_url = 'loginuser')           
def testRoomInterface(request):
    if request.method == 'GET':
        testRoomData = TestRoomInterface.objects.filter(update_profile = "Pending")
        return render(request, 'testroom.html', {"testRoomData" : testRoomData, 'form': TestRoomInterfaceForm()})

@login_required(login_url = 'loginuser')  
def updateTestRoomData(request, testroomid):
    if request.method == "POST":
        if request.user.is_authenticated :
            testRoomData = TestRoomInterface.objects.get(id=testroomid)
            testRoomData.testroom_remark = request.POST['testroom_remark']
            testRoomData.update_profile = request.POST['update_profile']
            testRoomData.onduty_staff = request.user
            testRoomData.onduty_staff_name = request.user.name
            testRoomData.save()

            testRoom = TestRoomInterface.objects.filter(update_profile = "Pending")
            return render(request, 'testroom.html', {"testRoomData" : testRoom, 'form': TestRoomInterfaceForm()})


@login_required(login_url = 'loginuser') 
def adminRoom(request):
    if request.method == 'GET':
        adminData = TestRoomInterface.objects.all()
        adminFilterForm = AdminFilter()
        return render(request, 'adminroom.html', {'adminData': adminData, 'filterForm' : adminFilterForm})

    else:
        depo = request.POST['pole_depo']
        status = request.POST['update_profile']

        adminData = TestRoomInterface.objects.filter(update_profile = status, pole_depo = depo)
        adminFilterForm = AdminFilter()

        return render(request, 'adminroom.html', {'adminData': adminData, 'filterForm' : adminFilterForm})

        


        

def QRInfoDATA(request):
    if request.method == 'GET':        
        poledata = CreatePoleModel.objects.all()         
    return render(request,'qrinfodata.html',{'userdata':poledata})
    



import qrcode
import qrcode.image.svg
from io import BytesIO

def index(request):
    
    return render(request, "test.html")

def createpole(request):
    if (request.method == 'GET'):
        return render(request,'CreatePole.html',{'form':CreatePoleModelForm()})
    else:
        
        latitude = request.POST.get("latitude")
        longitude = request.POST.get("longitude")
        print("Testing latitude", latitude)
        print("Testing longitude", longitude)
        form= CreatePoleModelForm(request.POST)
        obj_user = request.user            
        form.username = obj_user.name        
        newobj =form.save(commit=False)
        link = 'http://localhost:8000/qr/' + str(newobj.id)
        factory = qrcode.image.svg.SvgImage
        img = qrcode.make(link, image_factory=factory, box_size=20)
        stream = BytesIO()
        img.save(stream)
        newobj.svg = stream.getvalue().decode()
        newobj.qrlink = link
        newobj.save()
        return redirect('createpole')
    

def location(request):    
    return render(request,'location.html')

def SingleQRInfo(request):
    return render(request,'singleqrinfo.html')

