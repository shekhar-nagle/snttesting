from django.urls import path
from QRDataBase import views
# user defined url files
urlpatterns = [
    path('', views.index, name='home'),
    path('signup/', views.signup, name='signup'),
    path('loginuser/', views.loginuser, name='loginuser'),
    path('logoutuser/', views.logoutuser, name='logoutuser'), 
    
    path('singleqrinfo/', views.SingleQRInfo, name='singleqrinfo'),
    path('qrinfodata/', views.QRInfoDATA, name='qrinfodata'),
    path('qr/<str:search_by_qrlink>/', views.QRInfoByQRLink, name='QRInfoByQRLink'),
    path('adminn', views.adminn, name='adminn'),
    path('location', views.location, name='location'),
    path('createpole', views.createpole, name='createpole'),    
    
    path('testroominterface/', views.testRoomInterface, name='testroominterface'),
    path('testroom/update/<str:testroomid>/', views.updateTestRoomData, name="updateTestRoomData"),
    path('adminroom/', views.adminRoom, name ="adminRoom" ),
    path('test/', views.test, name ="test" ),
]